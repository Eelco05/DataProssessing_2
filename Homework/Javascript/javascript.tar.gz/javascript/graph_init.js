<script type="javascript" src="jscharts.js">
    var myChart = new JSChart('chartid', 'line');
    myChart.setDataXML("avg_temp.xml");
    myChart.draw();
</script>